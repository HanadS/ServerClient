/*  Verbose.java
 *  
 *  This class is used by the server threads to ensure
 *  the correct output is being applied. 
 *  
 *  Author:         Team 12 (Group Project - SYSC3303)
 *  Date:           6/3/2017
 */

public enum Verbose { 

    ON, OFF 

}